# grammar_parser.py
import re

LHS_NT = re.compile(r"^[A-Z]$")

def normalizar_flecha(linea: str) -> str:
    return linea.replace("→", "->")

def leer_gramatica_desde_texto(texto: str):
    producciones = []
    for linea in texto.splitlines():
        l = linea.strip()
        if not l or l.startswith("#"):
            continue
        l = normalizar_flecha(l)
        if "->" not in l:
            # No es producción; puede ser texto de autómata, se ignora aquí
            continue
        izq, der = [p.strip() for p in l.split("->", 1)]
        if not LHS_NT.match(izq):
            # Clave del arreglo: si LHS no es 1 mayúscula, NO es gramática
            raise ValueError(f"Detectado no-terminal inválido en gramática: '{izq}'")
        alts = [a.strip() for a in der.split("|")]
        for alt in alts:
            producciones.append((izq, "ε" if alt in ("", "eps") else alt))
    if not producciones:
        raise ValueError("No se detectaron producciones válidas.")
    return producciones
