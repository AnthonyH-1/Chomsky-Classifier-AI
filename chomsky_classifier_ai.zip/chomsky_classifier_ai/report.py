# report.py
from datetime import datetime
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import cm
except Exception:
    A4 = None

def export_pdf(path, titulo, entrada, resultado, explicacion, dot_path=None):
    if A4 is None:
        # Fallback .txt
        with open(path.replace(".pdf",".txt"), "w", encoding="utf-8") as f:
            f.write(f"{titulo}\n\nEntrada:\n{entrada}\n\nResultado:\n{resultado}\n\nExplicación:\n")
            for t in explicacion:
                f.write(f" - {t}\n")
        return path.replace(".pdf",".txt")

    c = canvas.Canvas(path, pagesize=A4)
    w,h = A4; y = h - 2*cm
    c.setFont("Helvetica-Bold", 14); c.drawString(2*cm, y, titulo); y -= 1*cm
    c.setFont("Helvetica", 10); c.drawString(2*cm, y, datetime.now().strftime("%Y-%m-%d %H:%M:%S")); y -= 1*cm

    def block(label, text):
        nonlocal y
        c.setFont("Helvetica-Bold", 11); c.drawString(2*cm, y, label); y -= 0.6*cm
        c.setFont("Helvetica", 10)
        for line in (text.splitlines() or ["—"]):
            c.drawString(2.2*cm, y, line[:110]); y -= 0.45*cm
        y -= 0.3*cm

    block("Entrada:", entrada)
    block("Resultado:", resultado)
    block("Explicación:", "\n".join(f" - {t}" for t in explicacion))
    if dot_path:
        block("Diagrama:", f"(DOT en {dot_path}. Exporta a PNG/SVG con Graphviz.)")
    c.showPage(); c.save()
    return path
