# visualizer.py
# Genera DOT (Graphviz) para gramáticas y autómatas.

def dot_gramatica(prods, name="G"):
    L = [f"digraph {name} {{", "rankdir=LR;", "node [shape=box];"]
    for i, (l, r) in enumerate(prods):
        L.append(f' p{i} [label="{l} -> {r}"];')
    nts = sorted({l for l,_ in prods})
    for nt in nts:
        L.append(f' "{nt}" [shape=circle];')
    for i, (l, _) in enumerate(prods):
        L.append(f' "{l}" -> p{i};')
    L.append("}")
    return "\n".join(L)

def dot_dfa(model):
    states = model["states"]; start = model["start"]; accept = set(model["accept"])
    trans = model["trans"]  # "q,a" -> [p]
    L = ["digraph DFA {","rankdir=LR;","node [shape=circle];"]
    for q in states:
        shape = "doublecircle" if q in accept else "circle"
        L.append(f' "{q}" [shape={shape}];')
    L.append(' i [shape=point];')
    L.append(f' i -> "{start}";')
    for k, dests in trans.items():
        q, a = k.split(",", 1)
        for p in dests:
            L.append(f' "{q}" -> "{p}" [label="{a}"];')
    L.append("}")
    return "\n".join(L)

def dot_pda(model):
    L = ["digraph PDA {","rankdir=LR;","node [shape=circle];"]
    accepts = set(model["accept"])
    for q in model["states"]:
        shape = "doublecircle" if q in accepts else "circle"
        L.append(f' "{q}" [shape={shape}];')
    L.append(f' i [shape=point]; i -> "{model["start"]}";')
    for (p,a,X),(q,gamma) in model["trans"]:
        lab = f"{a},{X}→{gamma}"
        L.append(f' "{p}" -> "{q}" [label="{lab}"];')
    L.append("}")
    return "\n".join(L)

def dot_tm(model):
    L = ["digraph TM {","rankdir=LR;","node [shape=circle];"]
    accepts = set(model["accept"])
    for q in model["states"]:
        shape = "doublecircle" if q in accepts else "circle"
        L.append(f' "{q}" [shape={shape}];')
    L.append(f' i [shape=point]; i -> "{model["start"]}";')
    for (q,a),(p,b,D) in model["trans"]:
        lab = f"{a}→{b},{D}"
        L.append(f' "{q}" -> "{p}" [label="{lab}"];')
    L.append("}")
    return "\n".join(L)

def guardar_dot(contenido: str, ruta="diagram.dot"):
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(contenido)
    return ruta
