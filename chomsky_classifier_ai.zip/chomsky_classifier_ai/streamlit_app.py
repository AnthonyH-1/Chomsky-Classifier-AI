# streamlit_app.py
# UI en Streamlit para:
# - Clasificar Gramática / AFD / AP / MT
# - Convertir Regex → AFD → Gramática Regular
# - Convertir GLC (Tipo 2) → AP (PDA) con validación
# - Quiz de clasificación
import os
import tempfile
import random
from datetime import datetime
import streamlit as st

from grammar_parser import leer_gramatica_desde_texto
from classifier import clasificar_gramatica
from automata_parser import parsear_automata
from automata_classifier import clasificar_automata
from visualizer import dot_gramatica, dot_dfa, dot_pda, dot_tm
from report import export_pdf

# Conversores
from converters import (
    regex_to_dfa_and_grammar,
    cfg_to_pda
)

st.set_page_config(page_title="Chomsky Classifier AI", layout="wide")
st.title("Chomsky Classifier AI")


# Utilidad: crea reporte y devuelve bytes para descarga

def _generar_reporte_pdf(entrada, resultado, trace, dot_str=None, dot_name=None):
    with tempfile.TemporaryDirectory() as tmp:
        dot_path = None
        if dot_str:
            dot_path = os.path.join(tmp, dot_name or "diagram.dot")
            with open(dot_path, "w", encoding="utf-8") as f:
                f.write(dot_str)
        out_path = os.path.join(tmp, f"reporte_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
        final_path = export_pdf(out_path, "Chomsky Classifier AI", entrada, resultado, trace, dot_path)
        with open(final_path, "rb") as f:
            data = f.read()
        if final_path.lower().endswith(".pdf"):
            return data, os.path.basename(final_path), "application/pdf"
        else:
            return data, os.path.basename(final_path), "text/plain"

tabs = st.tabs(["Clasificar", "Conversor", "Quiz"])

# TAB 1: CLASIFICAR
with tabs[0]:
    st.subheader("Clasificación automática")
    texto = st.text_area("Pega tu gramática o autómata AFD/AP/MT:", height=240)
    c1, c2 = st.columns(2)

    if c1.button("Clasificar", type="primary"):
        entrada = texto
        # 1) Intento como Gramática (estricto)
        try:
            prods = leer_gramatica_desde_texto(entrada)
            res = clasificar_gramatica(prods)
            st.success(f"{res['tipo']} — {res['maquina']}")
            with st.expander("Explicación"):
                for t in res["trace"]:
                    st.write("•", t)
            dot = dot_gramatica(prods)
            st.download_button("Descargar DOT (gramática)", dot, file_name="gramatica.dot")
            data, fname, mime = _generar_reporte_pdf(
                entrada=entrada,
                resultado=f"{res['tipo']} / {res['maquina']}",
                trace=res["trace"],
                dot_str=dot,
                dot_name="gramatica.dot"
            )
            st.download_button("Descargar Reporte", data=data, file_name=fname, mime=mime)
        except Exception:
            # 2) Intento como Autómata (AFD/AP/MT)
            try:
                model = parsear_automata(entrada)
                cres = clasificar_automata(model)
                st.success(f"{cres['tipo']} — {cres['maquina']} ({model['model']})")
                with st.expander("Explicación"):
                    for t in cres["trace"]:
                        st.write("•", t)
                if model["model"] in ("DFA", "NFA"):
                    dot = dot_dfa(model); dot_name = "automata_dfa.dot"
                elif model["model"] == "PDA":
                    dot = dot_pda(model); dot_name = "automata_pda.dot"
                else:
                    dot = dot_tm(model); dot_name = "automata_tm.dot"
                st.download_button("Descargar DOT (autómata)", dot, file_name=dot_name)
                data, fname, mime = _generar_reporte_pdf(
                    entrada=entrada,
                    resultado=f"{cres['tipo']} / {cres['maquina']} ({model['model']})",
                    trace=cres["trace"],
                    dot_str=dot,
                    dot_name=dot_name
                )
                st.download_button("Descargar Reporte", data=data, file_name=fname, mime=mime)
            except Exception:
                st.error("Entrada no reconocida. Revisa el formato o agrega encabezado AFD/AP/MT.")

# TAB 2: CONVERSOR
with tabs[1]:
    st.subheader("Regex → AFD → Gramática Regular")
    regex = st.text_input("Regex:")
    c1, c2 = st.columns(2)

    if c1.button("Convertir Regex", type="primary"):
        try:
            dfa, afd_text, gr_prods, gr_text = regex_to_dfa_and_grammar(regex)
            st.write("AFD derivado de la regex:")
            st.code(afd_text, language="text")
            st.write("Gramática regular derivada del AFD:")
            st.code(gr_text, language="text")
            dot = dot_dfa(dfa)
            st.download_button("Descargar DOT (AFD)", dot, file_name="regex_afd.dot")
            st.download_button("Descargar AFD.txt", afd_text, file_name="AFD_desde_regex.txt")
            st.download_button("Descargar GR.txt", gr_text, file_name="GR_desde_DFA.txt")
        except Exception as e:
            st.error(f"Error en conversión de regex: {e}")

    st.markdown("---")
    st.subheader("GLC → AP (PDA)  solo acepta gramáticas Tipo 2")
    glc_texto = st.text_area("Gramática libre de contexto:", height=200)

    if c2.button("Convertir GLC", type="primary"):
        try:
            prods = leer_gramatica_desde_texto(glc_texto)
            info = clasificar_gramatica(prods)
            if not info["tipo"].startswith("Tipo 2"):
                raise ValueError("El conversor GLC→AP solo acepta gramáticas Tipo 2. Usa la pestaña Clasificar para otros tipos.")
            pda_model, ap_text = cfg_to_pda(prods, start_symbol="S")
            st.write("Autómata con Pila derivado de la GLC:")
            st.code(ap_text, language="text")
            dotp = dot_pda(pda_model)
            st.download_button("Descargar DOT (AP)", dotp, file_name="pda_desde_glc.dot")
            st.download_button("Descargar AP.txt", ap_text, file_name="AP_desde_GLC.txt")
        except Exception as e:
            st.error(f"Error en conversión GLC→AP: {e}")

# TAB 3: QUIZ
with tabs[2]:
    st.subheader("Tutor de Chomsky  Quiz")
    # Estado
    if "quiz_item" not in st.session_state:
        st.session_state.quiz_item = None
    if "quiz_total" not in st.session_state:
        st.session_state.quiz_total = 0
    if "quiz_ok" not in st.session_state:
        st.session_state.quiz_ok = 0

    def gen_grammar_t3():
        # Reglas regulares simples
        choices = [
            "S -> aA | b | ε\nA -> aS | b",
            "S -> aS | bS | ε",
            "S -> aA | a | ε\nA -> b"
        ]
        return "\n".join(random.choice(choices).splitlines()), "Tipo 3", "Reglas lineales con a lo sumo un no terminal a la derecha."

    def gen_grammar_t2():
        choices = [
            "S -> aSb | ε",
            "S -> (S)S | ε",
            "S -> aS | B\nB -> bB | ε"
        ]
        return "\n".join(random.choice(choices).splitlines()), "Tipo 2", "Lado izquierdo con una variable. Permite anidar y equilibrar."

    def gen_grammar_t1():
        g = "S  -> aSBC | abc\nCB -> BC\naB -> ab\nbB -> bb\nbC -> bc\ncC -> cc"
        return g, "Tipo 1", "Aparecen varios símbolos en el lado izquierdo y no se reduce longitud."

    def gen_grammar_t0():
        g = "S  -> AB\nA  -> aA | a\nB  -> bB | b\nAB -> a"
        return g, "Tipo 0", "Regla con dos símbolos en el lado izquierdo que reduce longitud."

    def gen_dfa():
        a = "AFD\nstates: q0,q1\nstart: q0\naccept: q1\nq0 a -> q1\nq0 b -> q0\nq1 a -> q1\nq1 b -> q0"
        return a, "Tipo 3", "Un autómata finito reconoce lenguajes regulares."

    def gen_pda():
        a = "AP\nstates: p,q\nstart: p\naccept: q\nz0: Z\np, a, Z -> p, AZ\np, a, A -> p, AA\np, b, A -> p, eps\np, eps, Z -> q, Z"
        return a, "Tipo 2", "Un autómata con pila reconoce lenguajes libres de contexto."

    def gen_tm():
        a = "MT\nstates: q0,q1,qf\nstart: q0\naccept: qf\nblank: _\n(q0, a) -> (q1, b, R)\n(q1, b) -> (qf, b, N)"
        return a, "Tipo 0", "Una máquina de Turing reconoce lenguajes tipo 0."

    banks = [
        gen_grammar_t3, gen_grammar_t2, gen_grammar_t1, gen_grammar_t0,
        gen_dfa, gen_pda, gen_tm
    ]

    cols = st.columns(3)
    if cols[0].button("Nuevo ejercicio", type="primary"):
        maker = random.choice(banks)
        text, ans, expl = maker()
        st.session_state.quiz_item = {"text": text, "ans": ans, "expl": expl}
    if st.session_state.quiz_item:
        st.code(st.session_state.quiz_item["text"], language="text")
        choice = st.selectbox("Selecciona el tipo", ["Tipo 3", "Tipo 2", "Tipo 1", "Tipo 0"], index=None, placeholder="Elige una opción")
        if cols[1].button("Calificar"):
            if choice is None:
                st.warning("Selecciona una opción antes de calificar.")
            else:
                st.session_state.quiz_total += 1
                if choice == st.session_state.quiz_item["ans"]:
                    st.session_state.quiz_ok += 1
                    st.success(f"Correcto: {st.session_state.quiz_item['ans']}")
                else:
                    st.error(f"Incorrecto. Correcto: {st.session_state.quiz_item['ans']}")
                st.info(st.session_state.quiz_item["expl"])
        st.caption(f"Aciertos: {st.session_state.quiz_ok} / {st.session_state.quiz_total}")
    else:
        st.info("Haz clic en Nuevo ejercicio para comenzar.")
