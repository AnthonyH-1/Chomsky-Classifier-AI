# automata_classifier.py
def clasificar_automata(modelo: dict):
    m = modelo.get("model", "").upper()
    if m in ("DFA", "NFA"):
        return {
            "tipo": "Tipo 3 (Regular)",
            "maquina": "Autómata finito",
            "trace": [f"[AUTO] {m} detectado → Lenguaje Regular (Tipo 3)."]
        }
    if m == "PDA":
        return {
            "tipo": "Tipo 2 (Libre de Contexto)",
            "maquina": "Autómata con pila (AP)",
            "trace": ["[AUTO] PDA detectado → Lenguajes libres de contexto (Tipo 2)."]
        }
    if m == "LBA":
        return {
            "tipo": "Tipo 1 (Sensible al Contexto)",
            "maquina": "LBA",
            "trace": ["[AUTO] LBA detectado → Lenguajes sensibles al contexto (Tipo 1)."]
        }
    if m == "TM":
        return {
            "tipo": "Tipo 0 (Recursivamente enumerable)",
            "maquina": "Máquina de Turing",
            "trace": ["[AUTO] MT detectada → Lenguajes tipo 0."]
        }
    return {"tipo":"Desconocido","maquina":"N/A","trace":["Modelo no reconocido."]}
