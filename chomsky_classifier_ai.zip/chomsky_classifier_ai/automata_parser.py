# automata_parser.py
import re

HEADER = re.compile(r"^(AFD|AFN|AP|PDA|MT)\b", re.IGNORECASE)

def _lin(texto: str):
    for line in texto.splitlines():
        l = line.strip()
        if not l or l.startswith("#"):
            continue
        yield l

def detectar_tipo(texto: str):
    # 1) Encabezado explícito
    for l in _lin(texto):
        m = HEADER.match(l)
        if m:
            h = m.group(1).upper()
            return {"AFD":"DFA","AFN":"NFA","AP":"PDA","PDA":"PDA","MT":"TM"}[h]
        break
    body = "\n".join(list(_lin(texto)))
    # MT: (q,a) -> (p,b,D)
    if re.search(r"\([^)]+,\s*[^)]+\)\s*->\s*\([^)]+,\s*[^,]+,\s*[RrLlNn]\)", body):
        return "TM"
    # PDA: p, a, X -> q, gamma
    if re.search(r"^[A-Za-z0-9_]+\s*,\s*[^,]+\s*,\s*[^,]+\s*->\s*[A-Za-z0-9_]+\s*,", body, re.M):
        return "PDA"
    # DFA/NFA: q a -> p
    if re.search(r"^[A-Za-z0-9_]+\s+[^ \t]+?\s*->\s*[A-Za-z0-9_]+", body, re.M):
        return "DFA"
    return None

def parsear_afd(texto: str):
    states, start, accept, alphabet = set(), None, set(), set()
    trans = {}  # (q,a) -> set(destinos)
    for l in _lin(texto):
        low = l.lower()
        if low.startswith("states:"):
            states |= set(s.strip() for s in l.split(":",1)[1].split(","))
        elif low.startswith("start:"):
            start = l.split(":",1)[1].strip()
        elif low.startswith("accept:"):
            accept |= set(s.strip() for s in l.split(":",1)[1].split(","))
        elif low.startswith("alphabet:"):
            alphabet |= set(s.strip() for s in l.split(":",1)[1].split(","))
        else:
            m = re.match(r"^([A-Za-z0-9_]+)\s+([^\s]+)\s*->\s*([A-Za-z0-9_]+)$", l)
            if m:
                q, a, p = m.groups()
                states.update([q, p])
                if a != "eps":
                    alphabet.add(a)
                trans.setdefault((q, a), set()).add(p)
    model = "DFA"
    for _, dests in trans.items():
        if len(dests) > 1:
            model = "NFA"; break
    if not start and states:
        start = sorted(states)[0]
    return {
        "model": model,
        "states": sorted(states),
        "start": start,
        "accept": sorted(accept),
        "alphabet": sorted(alphabet),
        "trans": {f"{q},{a}": sorted(list(ps)) for (q,a), ps in trans.items()}
    }

def parsear_pda(texto: str):
    states, start, accept, z0 = set(), None, set(), None
    trans = []  # ((p,a,X) -> (q,gamma))
    for l in _lin(texto):
        low = l.lower()
        if low.startswith("states:"):
            states |= set(s.strip() for s in l.split(":",1)[1].split(","))
        elif low.startswith("start:"):
            start = l.split(":",1)[1].strip()
        elif low.startswith("accept:"):
            accept |= set(s.strip() for s in l.split(":",1)[1].split(","))
        elif low.startswith("z0:"):
            z0 = l.split(":",1)[1].strip()
        else:
            m = re.match(r"^([A-Za-z0-9_]+)\s*,\s*([^,]+)\s*,\s*([^,]+)\s*->\s*([A-Za-z0-9_]+)\s*,\s*(.+)$", l)
            if m:
                p, a, X, q, gamma = m.groups()
                trans.append(((p, a.strip(), X.strip()), (q.strip(), gamma.strip())))
                states.update([p, q])
    return {"model":"PDA","states":sorted(states),"start":start,"accept":sorted(accept),"z0":z0,"trans":trans}

def parsear_tm(texto: str):
    states, start, accept, blank = set(), None, set(), "_"
    trans = []  # ((q,a) -> (p,b,D))
    for l in _lin(texto):
        low = l.lower()
        if low.startswith("states:"):
            states |= set(s.strip() for s in l.split(":",1)[1].split(","))
        elif low.startswith("start:"):
            start = l.split(":",1)[1].strip()
        elif low.startswith("accept:"):
            accept |= set(s.strip() for s in l.split(":",1)[1].split(","))
        elif low.startswith("blank:"):
            blank = l.split(":",1)[1].strip()
        else:
            m = re.match(r"^\(([^,]+),\s*([^)]+)\)\s*->\s*\(([^,]+),\s*([^,]+),\s*([RrLlNn])\)$", l)
            if m:
                q,a,p,b,D = m.groups()
                trans.append(((q.strip(), a.strip()), (p.strip(), b.strip(), D.upper())))
                states.update([q.strip(), p.strip()])
    return {"model":"TM","states":sorted(states),"start":start,"accept":sorted(accept),"blank":blank,"trans":trans}

def parsear_automata(texto: str):
    t = detectar_tipo(texto)
    if t == "TM":
        return parsear_tm(texto)
    if t == "PDA":
        return parsear_pda(texto)
    if t == "DFA":
        return parsear_afd(texto)
    raise ValueError("No se detectó un autómata válido (AFD/AP/MT).")
