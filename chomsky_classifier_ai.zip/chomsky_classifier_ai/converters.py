# converters.py
# Conversores:
# - Regex → NFA → DFA → Gramática Regular
# - GLC → AP (PDA) (construcción estándar)
from collections import defaultdict, deque

# Regex → Postfix

def _is_symbol(ch: str) -> bool:
    return ch not in {'|', '*', '(', ')', '.'}

def _insert_concat_ops(regex: str) -> str:
    # Inserta '.' para concatenación explícita
    out = []
    n = len(regex)
    for i, c in enumerate(regex):
        out.append(c)
        if i+1 < n:
            a, b = c, regex[i+1]
            if ( _is_symbol(a) or a in {')','*'} ) and ( _is_symbol(b) or b == '(' ):
                out.append('.')
    return ''.join(out)

def _to_postfix(regex: str) -> str:
    prec = {'*':3, '.':2, '|':1}
    out, stack = [], []
    for c in regex:
        if _is_symbol(c):
            out.append(c)
        elif c == '(':
            stack.append(c)
        elif c == ')':
            while stack and stack[-1] != '(':
                out.append(stack.pop())
            if not stack:
                raise ValueError("Paréntesis desbalanceados")
            stack.pop()
        elif c in prec:
            if c == '*':
                # operador unario postfix: sacar operadores de mayor o igual precedencia a excepción de '('
                while stack and stack[-1] != '(' and prec.get(stack[-1],0) > prec[c]:
                    out.append(stack.pop())
                stack.append(c)
            else:
                while stack and stack[-1] != '(' and prec.get(stack[-1],0) >= prec[c]:
                    out.append(stack.pop())
                stack.append(c)
        else:
            raise ValueError(f"Símbolo no soportado en regex: {c}")
    while stack:
        op = stack.pop()
        if op in '()':
            raise ValueError("Paréntesis desbalanceados")
        out.append(op)
    return ''.join(out)

# Thompson: Postfix → NFA

class NFA:
    def __init__(self):
        self.start = None
        self.accept = None
        self.trans = defaultdict(lambda: defaultdict(set))  # trans[q][a] -> set(q')
        self.states = set()
        self.alphabet = set()

    def add_state(self):
        q = f"n{len(self.states)}"
        while q in self.states:
            q = f"n{len(self.states)+1}"
        self.states.add(q)
        return q

    def add_edge(self, q, a, p):
        self.trans[q][a].add(p)
        if a != 'eps':
            self.alphabet.add(a)

def _thompson_from_postfix(post: str) -> NFA:
    stack = []
    def lit(ch):
        nfa = NFA()
        s = nfa.add_state()
        f = nfa.add_state()
        nfa.start, nfa.accept = s, f
        a = 'eps' if ch == 'ε' else ch
        nfa.add_edge(s, a, f)
        return nfa

    def concat(a: NFA, b: NFA):
        n = NFA()
        # clonar a y b con renombrado simple
        def clone(src, prefix):
            mapping = {}
            for q in src.states:
                nq = f"{prefix}_{q}"
                mapping[q] = nq
                n.states.add(nq)
                for sym, dests in src.trans[q].items():
                    for d in dests:
                        pass
            for q in src.states:
                for sym, dests in src.trans[q].items():
                    for d in dests:
                        n.add_edge(mapping[q], sym, mapping[d])
            return mapping

        ma = clone(a, "A"); mb = clone(b, "B")
        n.start = ma[a.start]
        n.accept = mb[b.accept]
        n.add_edge(ma[a.accept], 'eps', mb[b.start])
        n.alphabet |= a.alphabet | b.alphabet
        return n

    def union(a: NFA, b: NFA):
        n = NFA()
        sa, fa = a, a
        sb, fb = b, b
        # clonar
        def clone_into(src, prefix):
            mapping = {}
            for q in src.states:
                nq = f"{prefix}_{q}"
                mapping[q] = nq
                n.states.add(nq)
            for q in src.states:
                for sym, dests in src.trans[q].items():
                    for d in dests:
                        n.add_edge(mapping[q], sym, mapping[d])
            return mapping
        ma = clone_into(a, "A"); mb = clone_into(b, "B")
        s = n.add_state(); f = n.add_state()
        n.start, n.accept = s, f
        n.add_edge(s, 'eps', ma[a.start])
        n.add_edge(s, 'eps', mb[b.start])
        n.add_edge(ma[a.accept], 'eps', f)
        n.add_edge(mb[b.accept], 'eps', f)
        n.alphabet |= a.alphabet | b.alphabet
        return n

    def star(a: NFA):
        n = NFA()
        m = {}
        for q in a.states:
            nq = f"A_{q}"; m[q] = nq; n.states.add(nq)
        for q in a.states:
            for sym, dests in a.trans[q].items():
                for d in dests:
                    n.add_edge(m[q], sym, m[d])
        s = n.add_state(); f = n.add_state()
        n.start, n.accept = s, f
        n.add_edge(s, 'eps', m[a.start])
        n.add_edge(s, 'eps', f)
        n.add_edge(m[a.accept], 'eps', m[a.start])
        n.add_edge(m[a.accept], 'eps', f)
        n.alphabet |= a.alphabet
        return n

    for c in post:
        if c == '*':
            a = stack.pop()
            stack.append(star(a))
        elif c == '.':
            b = stack.pop(); a = stack.pop()
            stack.append(concat(a, b))
        elif c == '|':
            b = stack.pop(); a = stack.pop()
            stack.append(union(a, b))
        else:
            stack.append(lit(c))
    if len(stack) != 1:
        raise ValueError("Regex inválida")
    return stack[0]

# NFA → DFA

def _eps_closure(nfa: NFA, states):
    stack = list(states)
    seen = set(states)
    while stack:
        q = stack.pop()
        for p in nfa.trans[q].get('eps', set()):
            if p not in seen:
                seen.add(p); stack.append(p)
    return frozenset(seen)

def _move(nfa: NFA, states, a):
    dest = set()
    for q in states:
        for p in nfa.trans[q].get(a, set()):
            dest.add(p)
    return dest

def nfa_to_dfa(nfa: NFA):
    alphabet = sorted([a for a in nfa.alphabet if a != 'eps'])
    start = _eps_closure(nfa, {nfa.start})
    queue = deque([start])
    seen = {start: "q0"}
    trans = {}
    accept = set()
    order = ["q0"]
    idx = 1
    while queue:
        S = queue.popleft()
        nameS = seen[S]
        if nfa.accept in S:
            accept.add(nameS)
        for a in alphabet:
            U = _eps_closure(nfa, _move(nfa, S, a))
            if not U:
                continue
            if U not in seen:
                seen[U] = f"q{idx}"; order.append(f"q{idx}"); idx += 1
                queue.append(U)
            nameU = seen[U]
            trans.setdefault((nameS, a), set()).add(nameU)
    states = order
    model = {
        "model": "DFA",
        "states": states,
        "start": "q0",
        "accept": sorted(accept),
        "alphabet": alphabet,
        "trans": {f"{q},{a}": sorted(list(ps)) for (q,a), ps in trans.items()}
    }
    return model

# DFA → Gramática Regular

def dfa_to_right_linear_grammar(dfa_model):
    states = dfa_model["states"]
    start = dfa_model["start"]
    accept = set(dfa_model["accept"])
    trans = dfa_model["trans"]  # "q,a" -> [p]
    # mapear estados a variables: start -> S, resto -> A,B,C,...
    vars_map = {}
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    vars_map[start] = "S"
    next_i = 0
    for q in states:
        if q == start: 
            continue
        v = letters[next_i] if next_i < len(letters) else f"X{next_i}"
        vars_map[q] = v
        next_i += 1
    prods = []
    # producciones por transición
    for key, dests in trans.items():
        q, a = key.split(",", 1)
        for p in dests:
            prods.append((vars_map[q], f"{a}{vars_map[p]}"))
    # ε en estados de aceptación
    for q in states:
        if q in accept:
            prods.append((vars_map[q], "ε"))
    return prods  # lista (LHS, RHS)

def render_grammar_text(prods):
    lines = []
    for l, r in prods:
        lines.append(f"{l} -> {r}")
    return "\n".join(lines)

def render_dfa_text(dfa_model):
    L = ["AFD",
         "states: " + ",".join(dfa_model["states"]),
         f"start: {dfa_model['start']}",
         "accept: " + ",".join(dfa_model["accept"])]
    # alphabet opcional
    # trans
    for key, dests in dfa_model["trans"].items():
        q, a = key.split(",", 1)
        for p in dests:
            L.append(f"{q} {a} -> {p}")
    return "\n".join(L)

# GLC → AP (PDA)

def cfg_to_pda(prods, start_symbol="S"):
    """
    Construcción estándar:
    - Estados: q, qf
    - z0: Z
    - q, eps, Z -> q, S Z
    - Para cada A->α: q, eps, A -> q, α^R   (α invertido para empujar en orden correcto)
    - Para cada terminal a: q, a, a -> q, eps
    - Aceptación por estado final: q, eps, Z -> qf, Z
    """
    states = ["q", "qf"]
    start = "q"
    accept = ["qf"]
    z0 = "Z"

    terminals = set()
    variables = set()
    for A, rhs in prods:
        variables.add(A)
        if rhs not in ("ε", "eps"):
            i = 0
            while i < len(rhs):
                c = rhs[i]
                if c.isupper():
                    variables.add(c)
                    i += 1
                else:
                    # terminals pueden ser cadenas minúsculas contiguas
                    j = i
                    while j < len(rhs) and not rhs[j].isupper():
                        j += 1
                    terminals.add(rhs[i:j])
                    i = j
        else:
            pass

    trans = []
    # Inicial
    trans.append((("q", "eps", z0), ("q", f"{start_symbol}{z0}")))
    # Reglas de producción: pop A y push α invertido
    for A, rhs in prods:
        if rhs in ("ε", "eps"):
            trans.append((("q", "eps", A), ("q", "eps")))
        else:
            syms = []
            i = 0
            while i < len(rhs):
                c = rhs[i]
                if c.isupper():
                    syms.append(c); i += 1
                else:
                    j = i
                    while j < len(rhs) and not rhs[j].isupper():
                        j += 1
                    syms.append(rhs[i:j]); i = j
            push = "".join(reversed(syms))  # invertido
            trans.append((("q", "eps", A), ("q", push)))
    # Consumo de terminales
    for a in sorted(t for t in terminals if t not in ("",)):
        trans.append((("q", a, a), ("q", "eps")))
    # Aceptación por estado final cuando vuelve Z al tope y entrada vacía
    trans.append((("q", "eps", z0), ("qf", z0)))

    model = {
        "model": "PDA",
        "states": states,
        "start": start,
        "accept": accept,
        "z0": z0,
        "trans": [((p,a,X),(q,g)) for ( (p,a,X),(q,g) ) in trans]
    }
    # Texto AP
    lines = ["AP",
             "states: " + ",".join(states),
             f"start: {start}",
             "accept: " + ",".join(accept),
             f"z0: {z0}"]
    for (p,a,X),(q,g) in trans:
        lines.append(f"{p}, {a}, {X} -> {q}, {g}")
    return model, "\n".join(lines)

# Principal del conversor

def regex_to_dfa_and_grammar(regex: str):
    """
    Devuelve: dfa_model, afd_text, grammar_prods, grammar_text
    """
    if not regex:
        raise ValueError("Regex vacía")
    regex = regex.replace(" ", "")
    regex = _insert_concat_ops(regex)
    post = _to_postfix(regex)
    nfa = _thompson_from_postfix(post)
    dfa = nfa_to_dfa(nfa)
    afd_text = render_dfa_text(dfa)
    gr_prods = dfa_to_right_linear_grammar(dfa)
    gr_text = render_grammar_text(gr_prods)
    return dfa, afd_text, gr_prods, gr_text
