# main.py
from grammar_parser import leer_gramatica_desde_texto
from classifier import clasificar_gramatica
from automata_parser import parsear_automata, detectar_tipo
from automata_classifier import clasificar_automata
from visualizer import dot_gramatica, dot_dfa, dot_pda, dot_tm, guardar_dot
from report import export_pdf

MENU = """
=== Chomsky Classifier AI ===
1) Analizar entrada (auto-detecta Gramática / AFD / AP / MT)
2) Generar reporte PDF del último análisis
3) Salir
"""

ultimo = None

def analizar(texto: str):
    global ultimo
    # 1) Intentar como AUTÓMATA primero
    try:
        from automata_parser import detectar_tipo, parsear_automata
        t = detectar_tipo(texto)
        if t:  # es AFD/AP/MT
            model = parsear_automata(texto)
            from automata_classifier import clasificar_automata
            cres = clasificar_automata(model)
            from visualizer import dot_dfa, dot_pda, dot_tm, guardar_dot
            if model["model"] in ("DFA","NFA"):
                dot = dot_dfa(model)
            elif model["model"] == "PDA":
                dot = dot_pda(model)
            else:
                dot = dot_tm(model)
            ruta = guardar_dot(dot, "automata.dot")
            ultimo = {
                "entrada_tipo": model["model"],
                "entrada_texto": texto,
                "resultado": cres["tipo"],
                "maquina": cres["maquina"],
                "trace": cres["trace"],
                "dot_path": ruta
            }
            print(f"\nModelo: {model['model']}\nTipo: {cres['tipo']}\nDOT: {ruta}\n")
            for tmsg in cres["trace"]:
                print(" -", tmsg)
            print()
            return
    except Exception as e:
        print("No se pudo analizar como autómata:", e)

    # 2) Si no fue autómata, intentar como GRAMÁTICA
    try:
        from grammar_parser import leer_gramatica_desde_texto
        from classifier import clasificar_gramatica
        from visualizer import dot_gramatica, guardar_dot

        prods = leer_gramatica_desde_texto(texto)
        res = clasificar_gramatica(prods)
        dot = dot_gramatica(prods)
        ruta = guardar_dot(dot, "gramatica.dot")
        ultimo = {
            "entrada_tipo": "Gramática",
            "entrada_texto": texto,
            "resultado": res["tipo"],
            "maquina": res["maquina"],
            "trace": res["trace"],
            "dot_path": ruta
        }
        print(f"\nTipo: {res['tipo']}\nMáquina: {res['maquina']}\nDOT: {ruta}\n")
        for tmsg in res["trace"]:
            print(" -", tmsg)
        print()
        return
    except Exception:
        pass

    print("Entrada no reconocida ni como gramática ni como autómata.")

def main():
    global ultimo
    while True:
        print(MENU)
        op = input("Opción: ").strip()
        if op == "1":
            print("Pega tu gramática o autómata. Línea vacía para terminar:\n")
            lines = []
            while True:
                l = input()
                if not l.strip():
                    break
                lines.append(l)
            analizar("\n".join(lines))
        elif op == "2":
            if not ultimo:
                print("Primero realiza un análisis (opción 1).\n"); continue
            path = export_pdf(
                "reporte.pdf",
                "Chomsky Classifier AI",
                ultimo["entrada_texto"],
                f"{ultimo['resultado']} / {ultimo['maquina']}",
                ultimo["trace"],
                ultimo["dot_path"]
            )
            print(f"Reporte exportado: {path}\n")
        elif op == "3":
            break
        else:
            print("Opción inválida\n")

if __name__ == "__main__":
    main()
