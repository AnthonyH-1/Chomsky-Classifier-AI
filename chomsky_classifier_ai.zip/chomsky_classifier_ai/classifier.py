# classifier.py
# Clasificador de gramáticas con modo explicativo (traza)

def es_no_terminal(x: str) -> bool:
    return len(x) == 1 and x.isalpha() and x.isupper()

def descomponer_derecha(d: str):
    d = d.strip()
    if d in ("ε", "e", "eps"):
        return ["EPS"]
    out = []
    i = 0
    while i < len(d):
        c = d[i]
        if c == " ":
            i += 1
            continue
        if c.isupper():
            out.append(("NT", c))
            i += 1
        else:
            j = i
            while j < len(d) and (not d[j].isupper()) and d[j] != " ":
                j += 1
            out.append(("T", d[i:j]))
            i = j
    return out

def es_tipo3(prods, trace):
    derecha = False
    izquierda = False
    for izq, der in prods:
        if not es_no_terminal(izq):
            trace.append(f"[T3] Falla: '{izq}' no es una sola variable mayúscula.")
            return False
        sim = descomponer_derecha(der)
        if sim == ["EPS"]:
            trace.append(f"[T3] OK: {izq} -> ε permitido.")
            continue
        nts = [s for s in sim if isinstance(s, tuple) and s[0] == "NT"]
        if len(nts) > 1:
            trace.append(f"[T3] Falla: {izq}->{der} tiene más de un no terminal.")
            return False
        if len(nts) == 0:
            trace.append(f"[T3] OK: {izq}->{der} solo terminales.")
            continue
        if len(sim) == 2:
            a, b = sim
            if a[0] == "T" and b[0] == "NT":
                derecha = True; trace.append(f"[T3] OK (derecha): {izq}->{der}.")
            elif a[0] == "NT" and b[0] == "T":
                izquierda = True; trace.append(f"[T3] OK (izquierda): {izq}->{der}.")
            else:
                trace.append(f"[T3] Falla forma regular en {izq}->{der}.")
                return False
        else:
            trace.append(f"[T3] Falla: {izq}->{der} no es A->aB, A->Ba o A->a.")
            return False
        if derecha and izquierda:
            trace.append("[T3] Falla: mezcla lineal a izquierda y derecha.")
            return False
    trace.append("[T3] Todas las reglas cumplen patrón regular.")
    return True

def es_tipo2(prods, trace):
    for izq, _ in prods:
        if not es_no_terminal(izq):
            trace.append(f"[T2] Falla: '{izq}' no es una sola variable.")
            return False
    trace.append("[T2] OK: todas las producciones tienen una variable a la izquierda.")
    return True

def es_tipo1(prods, trace):
    for izq, der in prods:
        l_izq = len(izq.replace(" ", ""))
        l_der = 0 if der in ("ε", "e", "eps") else len(der.replace(" ", ""))
        if l_der < l_izq and not (izq == "S" and l_der == 0):
            trace.append(f"[T1] Falla: {izq}->{der} reduce longitud.")
            return False
    trace.append("[T1] OK: ninguna producción reduce longitud (salvo S->ε).")
    return True

def clasificar_gramatica(prods):
    trace = []
    if es_tipo3(prods, trace):
        return {"tipo": "Tipo 3 (Regular)", "maquina": "Autómata finito (AFD/AFN)", "trace": trace}
    if es_tipo2(prods, trace):
        return {"tipo": "Tipo 2 (Libre de Contexto)", "maquina": "Autómata con pila (AP)", "trace": trace}
    if es_tipo1(prods, trace):
        return {"tipo": "Tipo 1 (Sensible al Contexto)", "maquina": "LBA", "trace": trace}
    trace.append("[T0] No cumple T3/T2/T1 → Tipo 0.")
    return {"tipo": "Tipo 0 (Recursivamente enumerable)", "maquina": "Máquina de Turing", "trace": trace}
